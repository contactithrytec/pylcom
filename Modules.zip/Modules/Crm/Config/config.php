<?php

return [
    'name' => 'Crm',
    'module_version' => "1.4",
    'pid' => 7
];
